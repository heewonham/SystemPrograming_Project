# 컴파일 및 실행방법

리눅스 환경에서 

1.  20172067.c

2.  20172067.h

3.  makefile

4.  opcode.txt

5. proga.obj

6. progb.obj

7. progc.obj

8. copy.obj

   상기 8가지를 동일한 폴더에 놓은 뒤

   명령어 'make'를 입력하면 컴파일과 object 파일과 생성한다.

   './20172067.out'을 이용하면 해당 프로그램을 실행할 수 있다.

   만약 .out , o 파일을 삭제하길 원한다면 'make clean'을 입력하면 된다.